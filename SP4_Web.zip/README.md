# SP4_Web

Follow Mr Quah MVC @Jeremy.

Types of Folder and their purpose:

css, js, images - Standard stuff
js/vendor - Library code like jQuery, TweenMax etc
js/, php/ - Your own custom code. Create different files for different purpose!! Don't merge them!!
php/class/ - Allows you to make coding process easier using OOP!

Password : &5gT*2epl!1f%