<?php

namespace React\Dns\Query;

final class TimeoutException extends \Exception
{
}
