<?php

namespace React\Dns;

final class BadServerException extends \Exception
{
}
