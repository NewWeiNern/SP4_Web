<?php

namespace React\Tests\Promise\Timer;

class CallableStub
{
    public function __invoke()
    {
    }
}
