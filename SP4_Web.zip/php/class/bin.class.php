<?php
    require_once "DB.php";

    class Bin extends DB{
        private $table = "tb_bin";
        public function __construct()
        {
            parent::__construct();
        }
        public function __destruct()
        {
            parent::__destruct();
        }
        public function location_exists($code){
            $this->prepare("SELECT * FROM $this->table WHERE bin_code=?");
            $this->bind("i", $code);
            $get = $this->get();
            $this->close_prepare();
            return $get;
        }
    }
?>

